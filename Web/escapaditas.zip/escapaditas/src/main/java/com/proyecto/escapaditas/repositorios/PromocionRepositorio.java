package com.proyecto.escapaditas.repositorios;

import com.proyecto.escapaditas.entidades.Promocion;
import org.springframework.data.repository.CrudRepository;

public interface PromocionRepositorio extends CrudRepository<Promocion, Long> {
}
